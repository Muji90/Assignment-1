package Store;

public interface GroceryProductFactory {
    GroceryProduct createProduct();
}
